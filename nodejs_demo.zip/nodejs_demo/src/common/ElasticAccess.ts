import { Service } from "@tsed/common";
import * as config from "config";
import { Client } from "elasticsearch";

@Service()
export class ElasticAccess {
    private esClient: any;

    constructor() {
        this.esClient = this.connect();
    }

    private connect() {
        return new Client({
            hosts: config.get("elasticsearch.endpoint"),
            log: [{
                type: "stdio",
                levels: ["error", "warning"]
            }]
        });
    }

    async search(args) {
        return await this.esClient.search(args);
    }

}
