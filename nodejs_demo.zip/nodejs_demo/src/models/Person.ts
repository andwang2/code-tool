import { JsonProperty } from "@tsed/common";
import { Example } from "@tsed/swagger";

export class Person {

  @Example("1000")
  @JsonProperty()
  public id: string;

  @Example("Andy")
  @JsonProperty()
  public name: string;

  public age?: string;
}
