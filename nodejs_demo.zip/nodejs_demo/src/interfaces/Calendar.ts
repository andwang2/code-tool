export interface Calendar {
  id: string;
  name: string;
  owner?: string;
}
