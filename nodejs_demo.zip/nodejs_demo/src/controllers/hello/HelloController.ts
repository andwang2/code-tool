import { Controller, Post, BodyParams } from "@tsed/common";
import { ElasticAccess } from "../../common/ElasticAccess";
import { Person } from "../../models/Person";

@Controller("/myapp")
export class HelloController {

  constructor(private esAccess: ElasticAccess) {

  }

  @Post("/hello")
  public sayHello(@BodyParams() person: Person) {
    return { "a": "b" };
  }

}
