import {Controller, Get, RouteService} from "@tsed/common";

@Controller("/myapp")
export class HelloController {

  constructor(private routeService: RouteService) {

  }

  @Get("/hello")
  public sayHello() {      
    return { "a":"b"};
  }

}
