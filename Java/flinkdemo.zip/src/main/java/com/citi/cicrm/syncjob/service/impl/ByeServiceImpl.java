package com.citi.cicrm.syncjob.service.impl;

import com.citi.cicrm.syncjob.service.MessageService;
import org.springframework.stereotype.Service;

@Service("byeService")
public class ByeServiceImpl implements MessageService {

    @Override
    public void printMessage() {
        System.out.println("This is goodbye service");
    }
}
