package com.citi.cicrm.syncjob.config;

public class Constants {
    public final static String DEFAULT_ENV = "dev";
}
