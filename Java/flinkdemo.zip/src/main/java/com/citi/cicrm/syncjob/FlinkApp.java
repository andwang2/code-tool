package com.citi.cicrm.syncjob;

import com.citi.cicrm.syncjob.sink.ElasticsearchSink;
import com.citi.cicrm.syncjob.source.ActivityDbSource;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

public class FlinkApp {

    public static void main(String[] args) throws Exception {
        ParameterTool parameterTool = ParameterTool.fromArgs(args);
        System.out.println("SERVER_ENV: " + parameterTool.get("SERVER_ENV"));
        // env
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.getConfig().setGlobalJobParameters(parameterTool);

        DataStreamSource<String> dataStreamSource = env.addSource(new ActivityDbSource());

        dataStreamSource.addSink(new ElasticsearchSink());

        env.execute("spring job");
    }
}
