package com.citi.cicrm.syncjob.source;

import com.citi.cicrm.syncjob.config.Constants;
import com.citi.cicrm.syncjob.service.MessageService;
import org.apache.commons.lang3.StringUtils;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.source.RichSourceFunction;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ActivityDbSource extends RichSourceFunction<String> implements ApplicationContextAware {
    private ApplicationContext applicationContext;

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
        if (applicationContext == null) {
            initIoc();
        }
    }

    private void initIoc() {
        ParameterTool parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();
        String serverEnv = StringUtils.isEmpty(parameterTool.get("SERVER_ENV")) ? Constants.DEFAULT_ENV : parameterTool.get("SERVER_ENV");
        applicationContext = new ClassPathXmlApplicationContext("classpath*:application-"+serverEnv+".xml");
    }

    @Override
    public void run(SourceContext<String> sourceContext) throws Exception {
        MessageService messageService = (MessageService) applicationContext.getBean("helloService");
        messageService.printMessage();

        sourceContext.collect("hello spring");
    }

    @Override
    public void cancel() {

    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

}
