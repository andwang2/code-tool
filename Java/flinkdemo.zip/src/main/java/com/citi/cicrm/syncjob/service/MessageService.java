package com.citi.cicrm.syncjob.service;

public interface MessageService {
    void printMessage();
}
