package com.example.demo.controllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@Api("HelloControllerApi")
public class HelloController {
    private static final Logger LOGGER = LoggerFactory.getLogger(HelloController.class);

    @Autowired
    ApplicationContext applicationContext;

    @ApiOperation(value = "say hello", notes = "say hello")
    @RequestMapping("/hello")
    public String hello(@RequestParam(value = "id",required = false) String id) {
        LOGGER.info(id);
        return "Hello Spring Boot!!";
    }

}