package com.example.demo.invocation;

import com.example.demo.services.HelloService;
import com.example.demo.services.interfaces.HelloInterface;

import java.lang.reflect.Proxy;

public class TestInvocation {

    public static void main(String[] args) {
        HelloService helloService = new HelloService();

        HelloInterface newProxyInstance = (HelloInterface) Proxy.newProxyInstance(helloService.getClass().getClassLoader(),
                helloService.getClass().getInterfaces(),
                new LoggerDynamicProxy(helloService));

        newProxyInstance.sayHi();
    }

}
