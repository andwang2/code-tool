package com.example.demo.invocation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

public class LoggerDynamicProxy implements InvocationHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(LoggerDynamicProxy.class);
    private Object target;

    public LoggerDynamicProxy(Object obj) {
        this.target = obj;
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        LOGGER.info("before calling...");
        Object obj = method.invoke(target, args);
        LOGGER.info("after calling...");
        return obj;
    }

}
