package com.example.demo.services.interfaces;

public interface HelloInterface {
}
