package com.example.demo.services;

import com.example.demo.services.interfaces.HelloInterface;
import org.springframework.stereotype.Service;

@Service
public class HelloService implements HelloInterface {

}
