package com.example.demo;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;


@RestController
@Api("HelloControllerApi")
public class HelloController {

	@ApiOperation(value = "say hello", notes = "say hello")
    @RequestMapping("/hello")
    public String hello() {
        return "Hello Spring Boot!";
    }
}