package com.citi.order;

public class Order {
    public static void addOrder() {
        System.out.println("ordered");
    }
}
