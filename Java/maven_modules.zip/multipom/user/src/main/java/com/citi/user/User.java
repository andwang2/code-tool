package com.citi.user;

import com.citi.order.Order;

public class User {
    public void orderProduct() {
        Order.addOrder();
    }
}
