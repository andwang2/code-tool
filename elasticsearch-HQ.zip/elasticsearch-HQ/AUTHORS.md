Roy Russo <royrusso@gmail.com>

Will McGinnis

And other authors: https://github.com/ElasticHQ/elasticsearch-HQ/graphs/contributors

This project also draws upon the work of the elasticsearch-py author:

Honza Král
And others: https://github.com/elastic/elasticsearch-py/blob/master/AUTHORS