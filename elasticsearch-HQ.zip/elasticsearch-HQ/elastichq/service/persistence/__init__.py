__author__ = 'royrusso'

from elastichq.service.persistence.ClusterDBService import *
