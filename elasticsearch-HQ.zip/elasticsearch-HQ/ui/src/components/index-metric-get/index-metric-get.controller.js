import './index-metric-get.style.scss'

class indexMetricGetController {

}

export default indexMetricGetController;
