
// Stubbed test.
describe('index-metric-get Component', () => {
  it('base test', () => {
    expect(1).toEqual(1);
  });
});
