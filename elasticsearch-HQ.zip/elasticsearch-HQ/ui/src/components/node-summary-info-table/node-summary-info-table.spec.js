
// Stubbed test.
describe('node-summary-info-table Component', () => {
  it('base test', () => {
    expect(1).toEqual(1);
  });
});
