import angular from 'angular';
import indexAliasesTabContent from './index-aliases-tab-content.component';

export default angular.module('eshq.indexAliasesTabContent', [])
  .component('eshqIndexAliasesTabContent', indexAliasesTabContent)
  .name;
