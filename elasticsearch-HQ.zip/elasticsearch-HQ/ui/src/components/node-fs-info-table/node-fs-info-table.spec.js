
// Stubbed test.
describe('node-fs-info-table Component', () => {
  it('base test', () => {
    expect(1).toEqual(1);
  });
});
