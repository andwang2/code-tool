
// Stubbed test.
describe('clusters Component', () => {
  it('base test', () => {
    expect(1).toEqual(1);
  });
});
