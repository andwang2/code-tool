import angular from 'angular';
import indexMetricOps from './index-metric-ops.component';

export default angular.module('eshq.indexMetricOps', [])
  .component('eshqIndexMetricOps', indexMetricOps)
  .name;
