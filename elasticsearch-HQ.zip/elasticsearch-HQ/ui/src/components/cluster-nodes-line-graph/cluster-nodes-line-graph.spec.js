
// Stubbed test.
describe('cluster-nodes-line-graph Component', () => {
  it('base test', () => {
    expect(1).toEqual(1);
  });
});
