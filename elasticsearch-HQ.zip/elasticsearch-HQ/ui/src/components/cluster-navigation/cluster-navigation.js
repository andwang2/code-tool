import angular from 'angular';
import clusterNavigation from './cluster-navigation.component';

export default angular.module('eshq.clusterNavigation', [])
  .component('eshqClusterNavigation', clusterNavigation)
  .name;
