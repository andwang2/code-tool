
// Stubbed test.
describe('indices-table Component', () => {
  it('base test', () => {
    expect(1).toEqual(1);
  });
});
