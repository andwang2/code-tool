
// Stubbed test.
describe('api-endpoints Component', () => {
  it('base test', () => {
    expect(1).toEqual(1);
  });
});
