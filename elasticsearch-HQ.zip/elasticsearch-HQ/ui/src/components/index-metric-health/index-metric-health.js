import angular from 'angular';
import indexMetricHealth from './index-metric-health.component';

export default angular.module('eshq.indexMetricHealth', [])
  .component('eshqIndexMetricHealth', indexMetricHealth)
  .name;
