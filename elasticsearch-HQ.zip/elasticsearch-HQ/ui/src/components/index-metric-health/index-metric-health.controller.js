import './index-metric-health.style.scss'

class indexMetricHealthController {
    constructor() {
        'ngInject';

        console.log('---- in indexMetricHealth', this)
    }
}

export default indexMetricHealthController;
