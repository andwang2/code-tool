
// Stubbed test.
describe('clusters-button Component', () => {
  it('base test', () => {
    expect(1).toEqual(1);
  });
});
