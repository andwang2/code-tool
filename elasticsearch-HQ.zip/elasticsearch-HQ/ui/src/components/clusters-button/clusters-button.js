import angular from 'angular';
import clustersButton from './clusters-button.component';

export default angular.module('eshq.clustersButton', [])
  .component('eshqClustersButton', clustersButton)
  .name;
