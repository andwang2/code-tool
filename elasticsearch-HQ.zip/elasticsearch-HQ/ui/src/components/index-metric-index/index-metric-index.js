import angular from 'angular';
import indexMetricIndex from './index-metric-index.component';

export default angular.module('eshq.indexMetricIndex', [])
  .component('eshqIndexMetricIndex', indexMetricIndex)
  .name;
