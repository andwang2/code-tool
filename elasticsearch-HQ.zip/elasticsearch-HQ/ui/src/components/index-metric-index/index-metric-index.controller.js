import './index-metric-index.style.scss'

class indexMetricIndexController {

}

export default indexMetricIndexController;
