import './index-metrics-tab-content.style.scss'

class indexMetricsTabContentController {
    constructor() {
        'ngInject';
    }
}

export default indexMetricsTabContentController;
