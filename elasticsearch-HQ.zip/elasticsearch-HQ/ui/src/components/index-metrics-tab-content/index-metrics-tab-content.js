import angular from 'angular';
import indexMetricsTabContent from './index-metrics-tab-content.component';

export default angular.module('eshq.indexMetricsTabContent', [])
  .component('eshqIndexMetricsTabContent', indexMetricsTabContent)
  .name;
