import './node-plugins-table.style.scss'

class nodePluginsTableController {

}

export default nodePluginsTableController;
