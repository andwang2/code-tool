
// Stubbed test.
describe('node-plugins-table Component', () => {
  it('base test', () => {
    expect(1).toEqual(1);
  });
});
