
// Stubbed test.
describe('node-os-info-table Component', () => {
  it('base test', () => {
    expect(1).toEqual(1);
  });
});
