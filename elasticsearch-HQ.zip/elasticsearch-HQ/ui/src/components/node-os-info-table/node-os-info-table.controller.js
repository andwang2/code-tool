import './node-os-info-table.style.scss'

class nodeOsInfoTableController {

}

export default nodeOsInfoTableController;
