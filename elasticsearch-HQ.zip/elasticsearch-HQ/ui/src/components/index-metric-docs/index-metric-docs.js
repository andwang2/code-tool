import angular from 'angular';
import indexMetricDocs from './index-metric-docs.component';

export default angular.module('eshq.indexMetricDocs', [])
  .component('eshqIndexMetricDocs', indexMetricDocs)
  .name;
