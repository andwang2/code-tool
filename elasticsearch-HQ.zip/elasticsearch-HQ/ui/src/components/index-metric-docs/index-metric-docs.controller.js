import './index-metric-docs.style.scss'

class indexMetricDocsController {

}

export default indexMetricDocsController;
