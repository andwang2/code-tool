
// Stubbed test.
describe('index-metric-docs Component', () => {
  it('base test', () => {
    expect(1).toEqual(1);
  });
});
