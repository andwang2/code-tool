
// Stubbed test.
describe('cluster-repositories Service', () => {
  it('base test', () => {
    expect(1).toEqual(1);
  });
});
