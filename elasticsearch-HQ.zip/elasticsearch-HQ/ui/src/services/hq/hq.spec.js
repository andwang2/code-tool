
// Stubbed test.
describe('hq Service', () => {
  it('base test', () => {
    expect(1).toEqual(1);
  });
});
