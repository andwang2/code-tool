import './settings.style.scss'

class settingsController {

  // Imports go here
  constructor() {
    'ngInject';
    
  }
}

export default settingsController;
