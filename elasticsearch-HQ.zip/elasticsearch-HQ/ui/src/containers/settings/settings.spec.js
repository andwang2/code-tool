
// Stubbed test.
describe('settings Container', () => {
  it('base test', () => {
    expect(1).toEqual(1);
  });
});
