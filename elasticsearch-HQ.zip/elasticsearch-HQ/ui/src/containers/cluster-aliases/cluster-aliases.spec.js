
// Stubbed test.
describe('cluster-aliases Container', () => {
  it('base test', () => {
    expect(1).toEqual(1);
  });
});
