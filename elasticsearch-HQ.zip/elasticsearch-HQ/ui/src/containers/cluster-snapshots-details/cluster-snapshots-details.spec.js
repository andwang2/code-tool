
// Stubbed test.
describe('cluster-snapshots-details Container', () => {
  it('base test', () => {
    expect(1).toEqual(1);
  });
});
