#!/usr/bin/env bash

ps ax | grep elasticsearch
