pkill -f elasticsearch
