import React, { Component } from "react";

export default class Home extends Component {

    constructor(props: any) {
        super(props);
        fetch("/hello", { method: 'GET' }).then(
            function (res) {
                console.log(res);
                res.json().then(function (data) {
                    console.log(data);
                });
            }
        )
    }

    render() {
        return (
            <div id="Home">
                This is home page.
            </div>
        )
    }
}