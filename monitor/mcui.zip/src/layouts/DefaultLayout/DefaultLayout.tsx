import React, {Component} from 'react';
import {Route} from 'react-router-dom';
import './DefaultLayout.less';
import HeadNav from '../../common/HeadNav'
import Home from '../../routes/Home/Home';
import About from '../../routes/About/About';
import { RouteComponentProps } from 'react-router';

interface Props extends RouteComponentProps { }

export default class DefaultLayout extends Component {
    matchUrl:any;

    constructor(props:Props) {
        super(props)
        this.matchUrl = props.match.url
    }

    render() {
        return (
            <div id="DefaultLayout">
                <HeadNav/>
                <div className="content-wrap">
                    <Route path={this.matchUrl+'/'} component={Home} exact />
                    <Route path={this.matchUrl+'/about'} component={About} />
                </div>
            </div>
        )
    }
}