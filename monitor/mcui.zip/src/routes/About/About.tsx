import React, {Component} from 'react';
import { Descriptions } from 'antd';

export default class About extends Component {
    render() {
        return (
            <div id="About">
                <Descriptions title="Read Me">
                    <Descriptions.Item label="UserName">xxx xxxx</Descriptions.Item>
                    <Descriptions.Item label="Telephone">1810000000</Descriptions.Item>
                    <Descriptions.Item label="Live">Hangzhou, Zhejiang</Descriptions.Item>
                    <Descriptions.Item label="Remark">empty</Descriptions.Item>
                    <Descriptions.Item label="Address">
                    No. 18, Wantang Road, Xihu District, Hangzhou, Zhejiang, China
                    </Descriptions.Item>
                    <Descriptions.Item label="Remark">empty</Descriptions.Item>
                </Descriptions>                
            </div>
        )
    }
}