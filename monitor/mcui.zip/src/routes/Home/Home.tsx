import React, { Component } from "react";
import { Card, Col, Row } from 'antd';
import './Home.less';
import { EditTwoTone, InfoCircleTwoTone } from '@ant-design/icons';

export default class Home extends Component {

    private serverStatus: any;

    constructor(props: any) {
        super(props);
        fetch("/hello", { method: 'GET' }).then(
            function (res) {
                console.log(res);
                res.json().then(function (data) {
                    console.log(data);
                });
            }
        )

        this.serverStatus = [
            {"serverName":"Elastic Server1", "cpu":"50%", "ram":"20G / 32G", "hd":"200G / 1000G", "swap":"100 MB / 2G", "host":"192.168.1.1"},
            {"serverName":"Elastic Server2", "cpu":"55%", "ram":"18G / 32G", "hd":"180G / 1000G", "swap":"100 MB / 2G", "host":"192.168.1.2"},
            {"serverName":"Elastic Server3", "cpu":"40%", "ram":"17G / 32G", "hd":"195G / 1000G", "swap":"100 MB / 2G", "host":"192.168.1.3"},
            {"serverName":"Elastic Server4", "cpu":"30%", "ram":"19G / 32G", "hd":"185G / 1000G", "swap":"100 MB / 2G", "host":"192.168.1.4"}
        ];
    }

    render() {
        const serverElements: any = [];

        this.serverStatus.forEach((item:any)=>{
            serverElements.push(
                <Col span={6}>
                    <Card title={item.serverName} bordered={false}
                        actions={[                                    
                            <EditTwoTone key="edit" title="Edit" />,
                            <InfoCircleTwoTone key="setting" title="View More Details" />,
                        ]}
                    >
                        CPU: {item.cpu} <br/>
                        Ram: {item.ram} <br/>
                        HD: {item.hd} <br/>
                        Swap: {item.swap} <br/>
                        IP (Host): {item.host}
                    </Card>
                </Col>
            )
        });

        return (
            <div id="Home">
                <div className="site-card-wrapper">
                    <Row gutter={16}>
                        {serverElements}                       
                    </Row>
                    <br/>
                    <Row gutter={16}>
                        <Col span={8}>
                            <Card title="Kafka Server s1" bordered={false}
                                actions={[                                    
                                    <EditTwoTone key="edit" />,
                                    <InfoCircleTwoTone key="setting" />,
                                  ]}
                            >                              
                                CPU: 60% <br/>
                                Ram: 20G / 32G <br/>
                                HD: 200G / 1000G <br/>
                                Swap: 100 MB / 2G
                            </Card>
                        </Col>
                        <Col span={8}>
                            <Card title="Redis Server s1" bordered={false}
                                actions={[                                    
                                    <EditTwoTone key="edit" />,
                                    <InfoCircleTwoTone key="setting" />,
                                  ]}
                            >                              
                                CPU: 60% <br/>
                                Ram: 20G/32G <br/>
                                HD: 200G / 1000G <br/>
                                Swap: 100 MB / 2G
                            </Card>
                        </Col>
                        <Col span={8}>
                            <Card title="Nginx Server s1" bordered={false}
                                actions={[                                    
                                    <EditTwoTone key="edit" />,
                                    <InfoCircleTwoTone key="setting" />,
                                  ]}
                            >                              
                                CPU: 60% <br/>
                                Ram: 20G/32G <br/>
                                HD: 200G / 1000G <br/>
                                Swap: 100 MB / 2G
                            </Card>
                        </Col>
                    </Row>                    
                </div>
            </div>
          
        )
    }
}