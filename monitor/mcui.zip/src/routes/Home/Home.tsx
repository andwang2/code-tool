import React, { Component } from "react";
import { Card, Col, Row } from 'antd';
import './Home.less';
import { Layout, Menu, Breadcrumb } from 'antd';
import {
  EditTwoTone, 
  InfoCircleTwoTone,
  DesktopOutlined,
  PieChartOutlined,
  FileOutlined,
  TeamOutlined,
  UserOutlined,
} from '@ant-design/icons';

const { Header, Content, Footer, Sider } = Layout;
const { SubMenu } = Menu;

export default class Home extends Component {

    private serverStatus: any;
    state = {
        collapsed: false,
    };

    constructor(props: any) {
        super(props);
        fetch("/hello", { method: 'GET' }).then(
            function (res) {
                console.log(res);
                res.json().then(function (data) {
                    console.log(data);
                });
            }
        )

        this.serverStatus = [
            {"serverName":"Elastic Server1", "cpu":"50%", "ram":"20G / 32G", "hd":"200G / 1000G", "swap":"100 MB / 2G", "host":"192.168.1.1"},
            {"serverName":"Elastic Server2", "cpu":"55%", "ram":"18G / 32G", "hd":"180G / 1000G", "swap":"100 MB / 2G", "host":"192.168.1.2"},
            {"serverName":"Elastic Server3", "cpu":"40%", "ram":"17G / 32G", "hd":"195G / 1000G", "swap":"100 MB / 2G", "host":"192.168.1.3"},
            {"serverName":"Elastic Server4", "cpu":"30%", "ram":"19G / 32G", "hd":"185G / 1000G", "swap":"100 MB / 2G", "host":"192.168.1.4"}
        ];
    }

    onCollapse = (collapsed:any) => {
        console.log(collapsed);
        this.setState({ collapsed });
    };

    render() {
        const serverElements: any = [];

        this.serverStatus.forEach((item:any)=>{
            serverElements.push(
                <Col span={6}>
                    <Card title={item.serverName} bordered={false}
                        actions={[                                    
                            <EditTwoTone key="edit" title="Edit" />,
                            <InfoCircleTwoTone key="setting" title="View More Details" />,
                        ]}
                    >
                        CPU: {item.cpu} <br/>
                        Ram: {item.ram} <br/>
                        HD: {item.hd} <br/>
                        Swap: {item.swap} <br/>
                        IP (Host): {item.host}
                    </Card>
                </Col>
            )
        });

        return (

            <Layout style={{ minHeight: '100vh' }}>
                <Sider collapsible collapsed={this.state.collapsed} onCollapse={this.onCollapse}>
                    <div className="logo" />
                    <Menu theme="dark" defaultSelectedKeys={['1']} mode="inline">
                        <Menu.Item key="1" icon={<PieChartOutlined />}>
                        Dashboard
                        </Menu.Item>
                        <Menu.Item key="2" icon={<DesktopOutlined />}>
                        Server Monitor
                        </Menu.Item>
                        <SubMenu key="sub1" icon={<UserOutlined />} title="Server Group">
                        <Menu.Item key="3">Elastic Cluster</Menu.Item>
                        <Menu.Item key="4">Redis Cluster</Menu.Item>
                        <Menu.Item key="5">Kafka Cluster</Menu.Item>
                        </SubMenu>
                        <SubMenu key="sub2" icon={<TeamOutlined />} title="Team">
                        <Menu.Item key="6">Team 1</Menu.Item>
                        <Menu.Item key="8">Team 2</Menu.Item>
                        </SubMenu>
                        <Menu.Item key="9" icon={<FileOutlined />} >
                            Help
                        </Menu.Item>    
                    </Menu>
                </Sider>

                <Layout className="site-layout">                
                    <Content style={{ margin: '0 16px' }}>
                        <div id="Home">              
                            <div className="site-card-wrapper">
                                <Row gutter={16}>
                                    {serverElements}                       
                                </Row>
                                <br/>
                                <Row gutter={16}>
                                    <Col span={8}>
                                        <Card title="Kafka Server s1" bordered={false}
                                            actions={[                                    
                                                <EditTwoTone key="edit" />,
                                                <InfoCircleTwoTone key="setting" />,
                                            ]}
                                        >                              
                                            CPU: 60% <br/>
                                            Ram: 20G / 32G <br/>
                                            HD: 200G / 1000G <br/>
                                            Swap: 100 MB / 2G
                                        </Card>
                                    </Col>
                                    <Col span={8}>
                                        <Card title="Redis Server s1" bordered={false}
                                            actions={[                                    
                                                <EditTwoTone key="edit" />,
                                                <InfoCircleTwoTone key="setting" />,
                                            ]}
                                        >                              
                                            CPU: 60% <br/>
                                            Ram: 20G/32G <br/>
                                            HD: 200G / 1000G <br/>
                                            Swap: 100 MB / 2G
                                        </Card>
                                    </Col>
                                    <Col span={8}>
                                        <Card title="Nginx Server s1" bordered={false}
                                            actions={[                                    
                                                <EditTwoTone key="edit" />,
                                                <InfoCircleTwoTone key="setting" />,
                                            ]}
                                        >                              
                                            CPU: 60% <br/>
                                            Ram: 20G/32G <br/>
                                            HD: 200G / 1000G <br/>
                                            Swap: 100 MB / 2G
                                        </Card>
                                    </Col>
                                </Row>                    
                            </div>
                        </div>
                        
                    </Content>
                    <Footer style={{ textAlign: 'center' }}>Monitor Center ©2020 Created by Xiaoming</Footer>
                </Layout>
          </Layout>           
          
        )
    }
}