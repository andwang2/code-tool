import React, { Component } from "react";
import { Card, Col, Row } from 'antd';
import './Home.less';
import { EditTwoTone, InfoCircleTwoTone } from '@ant-design/icons';

export default class Home extends Component {

    constructor(props: any) {
        super(props);
        fetch("/hello", { method: 'GET' }).then(
            function (res) {
                console.log(res);
                res.json().then(function (data) {
                    console.log(data);
                });
            }
        )
    }

    render() {
        return (
            <div id="Home">
                <div className="site-card-wrapper">
                    <Row gutter={16}>
                        <Col span={6}>
                            <Card title="Elastic Server" bordered={false}
                                actions={[                                    
                                    <EditTwoTone key="edit" title="Edit" />,
                                    <InfoCircleTwoTone key="setting" title="View More Details" />,
                                  ]}
                            >
                                CPU: 60% <br/>
                                Ram: 20G / 32G <br/>
                                HD: 200G / 1000G <br/>
                                Swap: 100 MB / 2G
                            </Card>
                        </Col>
                        <Col span={6}>
                            <Card title="Redis Server" bordered={false}
                                actions={[                                    
                                    <EditTwoTone key="edit" />,
                                    <InfoCircleTwoTone key="setting" />,
                                  ]}
                            >                            
                                CPU: 60% <br/>
                                Ram: 20G/32G <br/>
                                HD: 200G / 1000G <br/>
                                Swap: 100 MB / 2G
                            </Card>
                        </Col>
                        <Col span={6}>
                            <Card title="Nginx Server" bordered={false}
                                actions={[                                    
                                    <EditTwoTone key="edit" />,
                                    <InfoCircleTwoTone key="setting" />,
                                  ]}
                            >                            
                                CPU: 60% <br/>
                                Ram: 20G/32G <br/>
                                HD: 200G / 1000G <br/>
                                Swap: 100 MB / 2G
                            </Card>
                        </Col>
                        <Col span={6}>
                            <Card title="Nginx Server" bordered={false}
                                actions={[                                    
                                    <EditTwoTone key="edit" />,
                                    <InfoCircleTwoTone key="setting" />,
                                  ]}
                            >                            
                                CPU: 60% <br/>
                                Ram: 20G/32G <br/>
                                HD: 200G / 1000G <br/>
                                Swap: 100 MB / 2G
                            </Card>
                        </Col>                        
                    </Row>
                    <br/>
                    <Row gutter={16}>
                        <Col span={8}>
                            <Card title="Elastic Server s1" bordered={false}
                                actions={[                                    
                                    <EditTwoTone key="edit" />,
                                    <InfoCircleTwoTone key="setting" />,
                                  ]}
                            >                              
                                CPU: 60% <br/>
                                Ram: 20G / 32G <br/>
                                HD: 200G / 1000G <br/>
                                Swap: 100 MB / 2G
                            </Card>
                        </Col>
                        <Col span={8}>
                            <Card title="Redis Server s1" bordered={false}
                                actions={[                                    
                                    <EditTwoTone key="edit" />,
                                    <InfoCircleTwoTone key="setting" />,
                                  ]}
                            >                              
                                CPU: 60% <br/>
                                Ram: 20G/32G <br/>
                                HD: 200G / 1000G <br/>
                                Swap: 100 MB / 2G
                            </Card>
                        </Col>
                        <Col span={8}>
                            <Card title="Nginx Server s1" bordered={false}
                                actions={[                                    
                                    <EditTwoTone key="edit" />,
                                    <InfoCircleTwoTone key="setting" />,
                                  ]}
                            >                              
                                CPU: 60% <br/>
                                Ram: 20G/32G <br/>
                                HD: 200G / 1000G <br/>
                                Swap: 100 MB / 2G
                            </Card>
                        </Col>
                    </Row>                    
                </div>
            </div>
          
        )
    }
}