import React, { Component } from 'react';
import { Menu } from 'antd';
import { HomeOutlined, UserOutlined } from '@ant-design/icons';
import { Link } from 'react-router-dom'
import './HeadNav.less';

export default class HeadNav extends Component {

    state = {
        current: 'home',
    }    

    handleClick = (e: any) => {
        this.setState({ current: e.key });
    }

    render() {
        return (
            <div id="HeadNav">
                <div className="nav-wrap">
                    <div className="nav-logo-wrap">
                        Monitor Center
                    </div>

                    <div className="nav-list-wrap">

                        <Menu selectedKeys={[this.state.current]} mode="horizontal" onClick={this.handleClick}>
                            <Menu.Item key="home">
                                <HomeOutlined />
                                <Link to="/home">Home</Link>
                            </Menu.Item>

                            <Menu.Item key="aboutme">
                                <UserOutlined />
                                <Link to="/home/about">About MC</Link>
                            </Menu.Item>
                        </Menu>

                    </div>
                </div>
            </div>
        )
    }

}